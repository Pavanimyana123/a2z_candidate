// export const BASE_URL = "http://145.79.0.94:8000";

export const BASE_URL = "http://127.0.0.1:8000/";